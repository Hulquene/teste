<?php
echo "Teste";
echo "Teste";